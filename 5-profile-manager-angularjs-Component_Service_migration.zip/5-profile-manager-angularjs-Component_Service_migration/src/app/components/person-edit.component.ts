import { Component, Inject } from '@angular/core';
import { downgradeComponent } from '@angular/upgrade/static';
import * as angular from 'angular';
import { ContactService } from '../services/contact.service';
import { UIRouterState, UIRouterStateParams } from '../upgraded-providers';

@Component({
    selector: 'personEdit', //<person-edit></person-edit>
    templateUrl: `app/components/person-edit.component.html`
})
export class PersonEditComponent {

    private person = {};

    constructor(@Inject(UIRouterStateParams) private $stateParams: any,
        @Inject(UIRouterState) private $state: any,
        @Inject(ContactService) private contacts: ContactService) {

        this.person = this.contacts.getPerson(this.$stateParams.email);
    }

    save() {
        let self = this;
        this.contacts.updateContact(this.person)
            .then(function () {
                self.$state.go("list");
            });
    };

    remove() {
        let self = this;
        this.contacts.removeContact(this.person)
            .then(function () {
                self.$state.go("list");
            });
    };

}


angular
    .module("bytestream")
    .directive('personEdit', downgradeComponent({
        component: PersonEditComponent
    }));