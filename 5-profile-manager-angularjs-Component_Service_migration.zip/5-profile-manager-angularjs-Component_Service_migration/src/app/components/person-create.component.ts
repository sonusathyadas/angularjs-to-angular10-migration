
import { Component, Inject } from '@angular/core';
import { downgradeComponent } from '@angular/upgrade/static';
import * as angular from 'angular';
import { ContactService } from '../services/contact.service';
import { UIRouterState } from '../upgraded-providers';

@Component({
    selector: 'personCreate', // <person-create></person-create>
    templateUrl: `app/components/person-create.component.html`
})
export class PersonCreateComponent {
    private person = {
        name:'',
        email:'',
        photo:'',
        sex:'M',
        birthdate:'',
        phonenumber:'',
        address:'',
        city:'',
        country:''
    };

    constructor(@Inject(ContactService) private contacts:ContactService, 
        @Inject(UIRouterState) private $state:any) {
    }

    save() {
        console.log("createContact");
        let self= this;
        this.contacts.createContact(this.person)
            .then(function () {
                self.$state.go("list");
            });
    };
}

angular
    .module("bytestream")
    .directive('personCreate', downgradeComponent({
        component:PersonCreateComponent
    }));