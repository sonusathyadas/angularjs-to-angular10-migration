import './card.component';
import './spinner.component';
import './person-list.component';
import './search.component';
import './person-create.component';
import './person-edit.component';