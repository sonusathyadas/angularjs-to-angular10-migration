import * as angular from 'angular';

let personEditComponent = {
    selector: 'personEdit', //<person-edit></person-edit>
    template: `<div class="col-md-8 col-md-offset-2">
    <form class="form-horizontal"
          ng-submit="$ctrl.save()"
          novalidate>
      <div class="panel panel-default">
        <div class="panel-heading">
  
          {{mode}}
  
          <div class="pull-right">
            <button class="btn btn-primary btn-sm"
                    ladda="$ctrl.contacts.isSaving"
                    type="submit">Save
            </button>
  
            <button class="btn btn-danger btn-sm"
                    ladda="$ctrl.contacts.isDeleting"
                    ng-click="$ctrl.remove()">Delete
            </button>
          </div>
          <div class="clearfix"></div>
  
        </div>
        <div class="panel-body">
  
          <ng-include src="'templates/form.html'"></ng-include>
  
        </div>
      </div>
    </form>
  </div>`,
    bindings: {},
    controller: class PersonEditController {
        private $state;
        private $stateParams;
        private contacts;
        private person = {};

        constructor($stateParams, $state, ContactService) {
            this.$state = $state;
            this.$stateParams = $stateParams;
            this.contacts = ContactService;
            this.person = this.contacts.getPerson(this.$stateParams.email);
        }

        save() {
            let self=this; 
            this.contacts.updateContact(this.person)
                .then(function () {
                    self.$state.go("list");
                });
        };

        remove() {
            let self=this; 
            this.contacts.removeContact(this.person)
                .then(function () {
                    self.$state.go("list");
                });
        };

    }
}

angular
    .module("bytestream")
    .component(personEditComponent.selector, personEditComponent);