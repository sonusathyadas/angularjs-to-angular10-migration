import 'angular';
import 'angular-resource';
import 'angular-animate';
import 'angular-ui-router';
import 'angular-ladda';
import 'angular-spinner';
import 'angular-strap';
import 'angularjs-toaster';
import 'ng-infinite-scroll';
import 'angular-auto-validate/dist/jcs-auto-validate';

import './app.main';
import './services';
import './directives';
import './filters';
import './controllers';
import './app.routes';

