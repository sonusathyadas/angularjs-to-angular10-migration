import * as angular from 'angular';

angular
  .module("bytestream")
  .controller("PersonListController", function($scope, ContactService) {
    $scope.contacts = ContactService;
  })