angular-auto-validate
=====================

See http://jonsamwell.github.io/angular-auto-validate/ and my original blog post for more information http://jonsamwell.com/dynamic-angularjs-validation/

There is also more information available in the wiki https://github.com/jonsamwell/angular-auto-validate/wiki

See a demo here http://plnkr.co/edit/R4vGhrSYvKJREMV7Q4rC?p=preview