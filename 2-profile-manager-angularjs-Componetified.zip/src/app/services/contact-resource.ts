import * as angular from 'angular';

angular
  .module("bytestream")
  .factory("Contact", function($resource) {
    return $resource(
      "http://localhost:3000/profiles/:id",
      {id: "@id"},
      {
        update: {
          method: "PUT"
        }
      }
    );
  })